<?php
   require('conn.php');
   if(isset($_GET['t'])){
       $type=$_GET['t'];
       if($type=='AL'){
          $sql="select * from achieve";
       }
       else if($type=='A' || $type=='S'){
          $sql="select * from achieve where TYPE= '$type'";
       }
       else{
              header("location:error.html");
       }
   }
   
?>

<!DOCTYPE html>
<html lang="en">

<head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <meta http-equiv="X-UA-Compatible" content="ie=edge">
       <meta name="description" content="It has well maintained play-grounds, well equipped laboratories and modern classes.
          It also has very experienced faculty which help students to build their future.">
        <meta name="keywords" content="school,best school, school in Jabalpur, most rated school">
       <title>ACHIEVEMENTS - SANATAN DHARMA PUBLIC SCHOOL</title>
       <link rel="stylesheet" href="css/ach4.css">
       <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
       <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
   integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" 
   crossorigin="anonymous" />

</head>

<body>
       <div id="upper" class="upper">
              <img height="100px" width="150px" src="images/logo/logo.png" alt="" />
              <h1><b>SANATAN DHARMA PUBLIC HR. SEC. SCHOOL</b></h1>
              <h3>Hathital,Jabalpur, 482001</h3>
       </div> <br>

       <div class="dropdown hide">
              <form action="index.php">
                     <button  class="dropbtn"><h1><i class="fas fa-home"></i></h1> 
                     </button>
              </form>
       </div>
       <!--responsive side nav-->
       <div class="burger">
              <button onclick="opennav()">&#9776;</button>
       </div>
     <div id="mynav" class="sidenav ">
      <button onclick="closenav()" class="closeBtn">&cross;</button>
      <ul>
        <li>
              <h4 style="text-decoration: underline white;"><b>Administration</b></h4>
              <ul>
                  <li><a href="index.php#about"> <b>Home</b></a></li>
                 <li><a href="faculty.php?post=DIRECTOR"><b>Director</b></a> </li>
                <li><a href="faculty.php?post=PRINCIPAL"><b>Principal</b></a></li>
                <li><a href="faculty.php?post=TEACHER"><b>Staff</b></a></li>
              </ul>
      </li>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Academics</b></h4>
                            <ul>
                                   <li><a href="<?php echo $calender;?>"><b>Calender</b></a></li>
                                   <li><a href="<?php echo $feeStructure;?>"><b>Fees Structure</b></a></li>
                                   <li><a href="course.php"><b>Course Structure</b></a></li>
                                   <li><a href="student.php"><b>For Students</b></a></li>
                            </ul>
                     </li>
        <li><h4 style="text-decoration: underline white;"><b>Infrastructure</b></h4>
          <ul>
            <li><a href="photo.php?place=CLASSROOMS"><b>Class Rooms</b></a></li>
            <li><a href="photo.php?place=LABORATORY"><b>Laboratories</b></a></li>
            <li><a href="photo.php?place=PLAYGROUND"><b>Play Ground</b></a></li>
            <li><a href="photo.php?place=LIBRARY"><b>Library</b></a></li>
          </ul>
        </li>
        <li><h4 style="text-decoration: underline white;"><b>Achievements</b></h4>
          <ul>
            <li><a href="achieve.php?t=A"><b>Academics</b></a></li>
            <li><a href="achieve.php?t=S"><b>Sports</b></a></li>
          </ul>
        </li>
        <li><h4 style="text-decoration: underline white;"><b>Gallery</b></h4>
          <ul>
            <li><a href="photo.php?place=OTHER"><b>Photos</b></a></li>
          </ul>
        </li>
        <li><h4 style="text-decoration: underline white;"><b>Quick Links</b></h4>
          <ul>
            <li><a href="#contact"><b>Contact us</b></a></li>
            <li><a href="admin/login.php"><b>Admin Panel</b></a></li>
          </ul>
        </li>
        
      </ul>

  </div>
       <!--responsive side nav ends-->

       <!--main contents start-->
       <div class="box">
           <div class="heading">
               <h2>ACHIEVEMENTS:-</h2>
           </div>
           
           <?php
               $res=mysqli_query($conn,$sql);
               while($row=mysqli_fetch_assoc($res)){    ?>

               <div class="tile">
               <div class="left">
                <img src="<?php echo substr($row['IMAGE'],3)?>" alt="Student photo">
               </div>
               <div class="right">
                    <h2><span>Name</span> : <?php echo $row['NAME']?></h2>
                    <h2><span>Year</span> : <?php echo $row['YEAR']?></h2>
                    <h2><span>Achievement</span> : <?php echo $row['TEXT']?></h2>
                </div>
               </div>

           <?php  }
           ?>
           
       </div>
       <!--main contents ends-->

       
        <!--footer-->
     <div id="footer" class="footer">
       <div class="footer-one">
              <div class="image">
              <img src="images/logo/logo.png" alt="LOGO">
              </div>
              <div class="quote">
              <h3>Hardwork is the only key of success</h3>
              </div>
       </div>
       <div class="footer-two">
              <div class="link">
              <h2>QUICK LINKS</h2>
              <ul>
                     <li><a href="index.php"><b>Home</b></a></li>
                     <li><a href="course.php"><b>Course Structure</b></a></li>
                     <li><a href="<?php echo $feeStructure;?>"><b>Fees Structure</b></a></li>
                     <li><a href="achieve.php?t=AL"><b>Acheivements</b></a></li>
              </ul>
              </div>
       </div>
       <div class="footer-three">
              <div id="contact" class="contact">
              <h2>CONTACT US:</h2>
              <h4> Phone No : 0761-123456 </h4>
              <h4>   Email Id : xyz@gmail.com </h4>
              <h4>  Hathital,Jabalpur(M.P.)   </h4>
              
              </div>
              <div class="social">
              <h2>FOLLOW US:</h2> 
              <a href="#!"  class="text-white"><i title="Instagram" id="l1" class="fab fa-instagram"></i></a>
              <a href="#!"  class="text-white"><i title="Facebook"  id="l2" class="fab fa-facebook"></i></a>
              <a href="#!"  class="text-white"><i title="Linkedin"  id="l3" class="fab fa-linkedin"></i></a>
              <a href="#!"  class="text-white"><i title="Youtube"  id="l4" class="fab fa-youtube"></i></a>
              
              </div>
       
       </div>
       </div>
       <div class="footer-bottom"> <b>&copy; copyright || Designed by Rishabh Sondhiya</b>  
       </div>
       <!--footer-->

       <script>
              const opennav = () => {
                     document.getElementById("mynav").style.width = "200px";
              };
              const closenav = () => {
                     document.getElementById("mynav").style.width = "0px";
              };
       </script>

</body>

</html>