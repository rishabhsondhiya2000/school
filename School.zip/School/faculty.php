<?php
    require('conn.php');
    $post=$_GET['post'];
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>STAFF DETAILS- SANATAN DHARMA PUBLIC SCHOOL</title>
       <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
       <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
   integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" 
   crossorigin="anonymous" />
       <!--for body and header-->
       <link rel="stylesheet" href="css/faculty3.css">

</head>

<body>
       <div id="upper" class="upper">
              <img height="100px" width="150px" src="images/logo/logo.png" alt="" />
              <h1><b>SANATAN DHARMA PUBLIC HR. SEC. SCHOOL</b></h1>
              <h3>Hathital,Jabalpur, 482001</h3>
       </div> <br>

       <div class="dropdown hide">
              <form class="" action="index.php" >
                     <button  class="dropbtn">
                     <h1><i class="fas fa-home"></i></h1> </button>
              </form>
       </div>

       <!--responsive side nav-->
       <div class="burger">
              <button onclick="opennav()">&#9776;</button>
       </div>
     <div id="mynav" class="sidenav ">
      <button onclick="closenav()" class="closeBtn">&cross;</button>
      <ul>
        <li>
              <h4 style="text-decoration: underline white;"><b>Administration</b></h4>
              <ul>
                  <li><a href="index.php#about"> <b>Home</b></a></li>
                 <li><a href="faculty.php?post=DIRECTOR"><b>Director</b></a> </li>
                <li><a href="faculty.php?post=PRINCIPAL"><b>Principal</b></a></li>
                <li><a href="faculty.php?post=TEACHER"><b>Staff</b></a></li>
              </ul>
      </li>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Academics</b></h4>
                            <ul>
                                   <li><a href="<?php echo $calender;?>"><b>Calender</b></a></li>
                                   <li><a href="<?php echo $feeStructure;?>"><b>Fees Structure</b></a></li>
                                   <li><a href="course.php"><b>Course Structure</b></a></li>
                                   <li><a href="student.php"><b>For Students</b></a></li>
                            </ul>
                     </li>
        <li><h4 style="text-decoration: underline white;"><b>Infrastructure</b></h4>
          <ul>
            <li><a href="photo.php?place=CLASSROOMS"><b>Class Rooms</b></a></li>
            <li><a href="photo.php?place=LABORATORY"><b>Laboratories</b></a></li>
            <li><a href="photo.php?place=PLAYGROUND"><b>Play Ground</b></a></li>
            <li><a href="photo.php?place=LIBRARY"><b>Library</b></a></li>
          </ul>
        </li>
        <li><h4 style="text-decoration: underline white;"><b>Achievements</b></h4>
          <ul>
            <li><a href="achieve.php?t=A"><b>Academics</b></a></li>
            <li><a href="achieve.php?t=S"><b>Sports</b></a></li>
          </ul>
        </li>
        <li><h4 style="text-decoration: underline white;"><b>Gallery</b></h4>
          <ul>
            <li><a href="photo.php?place=OTHER"><b>Photos</b></a></li>
          </ul>
        </li>
        <li><h4 style="text-decoration: underline white;"><b>Quick Links</b></h4>
          <ul>
            <li><a href="#contact"><b>Contact us</b></a></li>
            <li><a href="admin/login.php"><b>Admin Panel</b></a></li>
          </ul>
        </li>
        
      </ul>

     </div>

       <div style=" text-decoration: underline 1px rgb(161, 6, 6);" class="heading">
              <h1><strong>OUR PROUD FACULTIES:-</strong></h1>
              
       </div>
       <br>
       <!--------------------------------------------->
       <div  class="heading">
              <h2><strong><?php echo $post;?>:-</strong></h2>
              
       </div>

       <div class="section">
              <div class="cc">
                     <?php
                       $sql="SELECT * FROM teachers where POST='$post'";
                       
                       if($result=mysqli_query($conn, $sql)){
                           while($row=mysqli_fetch_assoc($result)){
                                $img=$row['IMAGE'];
                                $img=substr($img,3);
                                echo"<div class='row '>
                                   <div   class='col top'>
                                          <div class='photo'>
                                               <img src='".$img."'/> 
                                          </div>
                                   </div>
                                   <div   class='col bottom'>
                                          <div class='details'>
                                                 <h5><b> NAME </b>: ".$row['NAME']."</h5>
                                                 <h5><b> AGE </b>: ".$row['AGE']."</h5>
                                                 <h5><b> POST </b>: ".$row['POST']."</h5>
                                                 <h5><b> EXPERIENCE </b>: ".$row['EXPERIENCE']."</h5>
                                          </div>
                                   </div>     
                                </div>  ";
                           }    
                       }
                     ?> 
                 </div>
       </div>



       <!--footer-->
       <div id="footer" class="footer">
              <div class="footer-one">
                     <div class="image">
                     <img src="images/logo/logo.png" alt="LOGO">
                     </div>
                     <div class="quote">
                     <h3>Hardwork is the only key of success</h3>
                     </div>
              </div>
              <div class="footer-two">
                     <div class="link">
                     <h2>QUICK LINKS</h2>
                     <ul>
                            <li><a href="index.php"><b>Home</b></a></li>
                            <li><a href="course.php"><b>Course Structure</b></a></li>
                            <li><a href="<?php echo $feeStructure;?>"><b>Fees Structure</b></a></li>
                            <li><a href="achieve.php?t=AL"><b>Acheivements</b></a></li>
                     </ul>
                     </div>
              </div>
              <div class="footer-three">
                     <div id="contact" class="contact">
                     <h2>CONTACT US:</h2>
                     <h4> Phone No : 0761-123456 </h4>
                     <h4>   Email Id : xyz@gmail.com </h4>
                     <h4>  Hathital,Jabalpur(M.P.)   </h4>
                     
                     </div>
                     <div class="social">
                     <h2>FOLLOW US:</h2> 
                     <a href="#!"  class="text-white"><i title="Instagram" id="l1" class="fab fa-instagram"></i></a>
                     <a href="#!"  class="text-white"><i title="Facebook"  id="l2" class="fab fa-facebook"></i></a>
                     <a href="#!"  class="text-white"><i title="Linkedin"  id="l3" class="fab fa-linkedin"></i></a>
                     <a href="#!"  class="text-white"><i title="Youtube"  id="l4" class="fab fa-youtube"></i></a>
                     
                     </div>
              
              </div>
              </div>
              <div class="footer-bottom"> <b>&copy; copyright || Designed by Rishabh Sondhiya</b>  
              </div>
       <!--footer-->

       <script>
              const opennav = () => {
                     document.getElementById("mynav").style.width = "200px";
              };
              const closenav = () => {
                     document.getElementById("mynav").style.width = "0px";
              };
       </script>
</body>

</html>