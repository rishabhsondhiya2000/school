<?php
    $conn=mysqli_connect("localhost","root","","school");
    if(!$conn){
        die("Connection Failed");
    }
    $post=$_GET['post'];
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
       <meta charset="UTF-8">
       <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <title>STAFF DETAILS- SANATAN DHARMA PUBLIC SCHOOL</title>
       <link rel="shortcut icon" href="favicon.png" type="image/x-icon">
       <link href="https://fonts.googleapis.com/css2?family=Ubuntu:wght@300&display=swap" rel="stylesheet">

       <!--for body and header-->
       <link rel="stylesheet" href="css/faculty.css">

</head>

<body>
       <div id="upper" class="upper">
              <img height="100px" width="150px" src="images/logo/logo.png" alt="" />
              <h1><b>SANATAN DHARMA PUBLIC HR. SEC. SCHOOL</b></h1>
              <h3>Hathital,Jabalpur, 482001</h3>
       </div> <br>

       <div class="dropdown hide">
              <form action="index.html">
                     <button  class="dropbtn">
                     &#x1F519; </button>
              </form>
       </div>

       <!--responsive side nav-->
       <div class="burger">
              <button onclick="opennav()">&#9776;</button>
       </div>
       <div id="mynav" class="sidenav ">
              <button onclick="closenav()" class="closeBtn">&cross;</button>
              <ul>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Administration</b></h4>
                            <ul>
                                   <li><a href="index.html#about"> <b> About Us</b></a></li>
                                   <li><a href="http://localhost/school/faculty.php?post=DIRECTOR"><b>Director</b></a>
                                   </li>
                                   <li><a href="http://localhost/school/faculty.php?post=PRINCIPAL"><b>Principal</b></a>
                                   </li>
                                   <li><a href="http://localhost/school/faculty.php?post=TEACHER"><b>Staff</b></a></li>
                            </ul>
                     </li>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Academics</b></h4>
                            <ul>
                                   <li><a href="document/Admission/sign.pdf"><b>Admission</b></a></li>
                                   <li><a href="document/Fees Structure/sign.pdf"><b>Fees Structure</b></a></li>
                                   <li><a href="http://localhost/school/course.php"><b>Course Structure</b></a></li>
                            </ul>
                     </li>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Infrastructure</b></h4>
                            <ul>
                                   <li><a href="http://localhost/school/photo.php?place=CLASS-ROOMS"><b>Class
                                                        Rooms</b></a></li>
                                   <li><a href="http://localhost/school/photo.php?place=LABORATORY"><b>Laboratories</b></a>
                                   </li>
                                   <li><a href="http://localhost/school/photo.php?place=PLAY-GROUND"><b>Play
                                                        Ground</b></a></li>
                                   <li><a href="http://localhost/school/photo.php?place=LIBRARY"><b>Library</b></a></li>
                            </ul>
                     </li>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Achievements</b></h4>
                            <ul>
                                   <li><a href="http://localhost/school/achieve.php?t=1"><b>Academics</b></a></li>
                                   <li><a href="http://localhost/school/achieve.php?t=2"><b>Sports</b></a></li>
                            </ul>
                     </li>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Gallery</b></h4>
                            <ul>
                                   <li><a href="http://localhost/school/photo.php?place=OTHER"><b>Photos</b></a></li>
                            </ul>
                     </li>
                     <li>
                            <h4 style="text-decoration: underline white;"><b>Quick Links</b></h4>
                            <ul>
                                   <li><a href="#footer"><b>Contact us</b></a></li>
                            </ul>
                     </li>

              </ul>

       </div>

       <div style=" text-decoration: underline 1px rgb(161, 6, 6);" class="heading">
              <h1><strong>OUR PROUD FACULTIES:-</strong></h1>
              
       </div>
       <br>
       <!--------------------------------------------->
       <div style=" text-decoration: underline 1px rgb(161, 6, 6);" class="heading">
              <h2><strong><?php echo $post;?>:-</strong></h2>
              
       </div>

       <div class="section">
              <div class="cc">
                     <?php
                       $sql="SELECT * FROM teachers where POST='$post'";
                       
                       if($result=mysqli_query($conn, $sql)){
                           while($row=mysqli_fetch_assoc($result)){
                 
                                echo"<div class='row '>
                                   <div   class='col top'>
                                          <div class='photo'>
                                               <img src='".$row['IMAGE']."'/> 
                                          </div>
                                   </div>
                                   <div   class='col bottom'>
                                          <div class='details'>
                                                 <h5><b> NAME </b>: ".$row['NAME']."</h5>
                                                 <h5><b> AGE </b>: ".$row['AGE']."</h5>
                                                 <h5><b> POST </b>: ".$row['POST']."</h5>
                                                 <h5><b> EXPERIENCE </b>: ".$row['EXPERIENCE']."</h5>
                                          </div>
                                   </div>     
                                </div>  ";
                           }    
                       }
                     ?> 
                 </div>
       </div>



       <!--footer-->
       <div class="footer">

              <div class="footer-bottom">
              &copy; Designed by Rishabh Sondhiya
              </div>
       </div>
       <!--footer-->

       <script>
              const opennav = () => {
                     document.getElementById("mynav").style.width = "200px";
              };
              const closenav = () => {
                     document.getElementById("mynav").style.width = "0px";
              };
       </script>
</body>

</html>