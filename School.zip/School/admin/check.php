<?php
  $otp=$_POST['otp'];
  session_start();
  if(isset($_COOKIE['emailOTP'])){
      $actual_otp=$_COOKIE['emailOTP'];
      if($otp==$actual_otp){
           $_SESSION['mode']="change";
           header("location:login.php");
      }
      else{
          $_SESSION['error']="You entered wrong OTP!";
          $_SESSION['mode']="sent";
          header("location:login.php");
      }
  }
  else{
    $_SESSION['error']="Wrong OTP.";
     header("location:login.php?m=forget");
  }


?>