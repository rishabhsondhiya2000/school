<?php
require('conn.php');
session_start();
$pass=$_POST['password'];
$conf_pass=$_POST['confirm_password'];
if($pass==$conf_pass){
    mysqli_query($conn,"UPDATE admin set password='$pass'");
    $_SESSION["error"]="Password is updated! Log In now :)";
    $_SESSION['mode']="login";
    header("location:login.php");
}
else{
    $_SESSION['error']="Confrim Password not matched";
    header('location:login.php');
}
?>