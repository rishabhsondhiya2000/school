<?php
  require("conn.php");
  session_start();
  if(!isset($_SESSION['isLogin'])){
    $_SESSION['error']="Invalid User";  
    header("location:login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">
    
    <link rel="shortcut icon" href="../favicon.png" type="image/x-icon">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"
   integrity="sha512-HK5fgLBL+xu6dm/Ii3z4xhlSUyZgTT9tuc/hSrtw6uzJOvgRr2a9jyxxT1ely+B+xFAmJKVSTbpM/CuL7qxO8w==" 
   crossorigin="anonymous" />
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
    integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="css/theme3.css" rel="stylesheet" media="all">

</head>

<body>
    
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="../images/logo/logo.png" alt="CoolAdmin" />
                        </a>
                        <!-- <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button> -->
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li >
                            <a  href="{{url('admin/dashboard">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                            
                        </li>
                        <li >
                            <a  href="{{url('admin/category">
                                <i class="fas fa-list"></i>Category</a>
                            
                        </li>
                        <li >
                            <a  href="{{url('admin/coupon">
                                <i class="fas fa-tags"></i></i>Coupons</a>
                           
                        </li>
                       
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="../images/logo/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li id="Dashboard" class="" >
                            <a  href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                           
                        </li>
                        <li id="About-Dashboard" class="">
                            <a  href="about.php">
                                <i class="fas fa-list"></i>About</a>
                           
                        </li>
                        <li id="Important News-Dashboard" >
                            <a  href="impnews.php">
                            <i class="fas fa-bell"></i>Important News</a>
                           
                        </li>
                        <li id="Staff-Dashboard" >
                            <a  href="staff.php">
                            <i class="fas fa-chalkboard-teacher"></i></i>Staffs</a>
                           
                        </li>
                        <li id="Students-Dashboard" >
                            <a  href="student.php">
                                <<i class="fas fa-user-graduate"></i>Students</a>
                           
                        </li>
                        <li id="Photo-Dashboard" >
                            <a  href="pic.php">
                            <i class="fas fa-images"></i>Images</a>
                           
                        </li>
                        <li id="PDFs - Dashboard" >
                            <a  href="pdf.php">
                            <i class="fas fa-file-pdf"></i>Pdfs</a>
                           
                        </li>
                        <li id="Achievements-Dashboard" >
                            <a  href="ach.php">
                            <i class="fas fa-trophy"></i>Achievements</a>
                           
                        </li>
                        <li id="Slider-Dashboard" >
                            <a  href="slider.php">
                            <i class="fas fa-camera-retro"></i>Slider</a>
                           
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap height">
                            <form class="form-header" action="" method="POST">
                                
                            </form>
                            <div class="header-button">
                                 
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                
                                        <div class="content">
                                            <a style="color:white;" class="btn btn-primary" href="logout.php"><b>LOGOUT</b></a>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <h1>Welcome Admin</h1>
                        
                    </div>
                </div>
            </div>
        </div>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script>
            $(document).ready(function(){
                    var title=document.title;
                    $("#"+title).addClass("active");
                
            });
        </script>
</body>

</html>
<!-- end document-->