<?php
 require('conn.php');
 $id=$_GET['id'];
 $for=$_GET['f'];
 session_start();
 
 $file_name=$_FILES['file']['name'];
 $file_Temp=$_FILES['file']['tmp_name'];
 $file_size=$_FILES['file']['size'];
 $file_type=$_FILES['file']['type'];
 $file_error=$_FILES['file']['error'];
 if($for=="staff"){

      if($file_error=="4"){
            $name= strtoupper($_POST['data_name']);
            $age=$_POST['data_age'];
            $exp=$_POST['data_exp'];
            $post=$_POST['data_post'];
            mysqli_query($conn,"UPDATE teachers set NAME='$name',AGE='$age',POST='$post',EXPERIENCE='$exp' where S_NO='$id'");
            header("location:staff.php");
      }
      else{
      $file_ext=explode('.' , $file_name);
      $file_act_ext=strtolower(end($file_ext));

      $allowed_ext=array('png','jpg','jpeg');

      if(in_array( $file_act_ext , $allowed_ext)){
            if($file_error=== 0){
                  if($file_size < 10000000){
                  $file_new_name=uniqid('',true).".". $file_act_ext;
                  $file_destination = "../images/staff/". $file_new_name;
                  //$file_destination= "../try/".$file_new_name;
      
                  move_uploaded_file($file_Temp, $file_destination);
                  $row=mysqli_fetch_assoc(mysqli_query($conn,"select * from teachers where S_NO='$id'"));
                  unlink($row['IMAGE']);
                  $name= strtoupper($_POST['data_name']);
                  $age=$_POST['data_age'];
                  $exp=$_POST['data_exp'];
                  $post=$_POST['data_post'];
                  mysqli_query($conn,"UPDATE teachers set NAME='$name',AGE='$age',POST='$post',EXPERIENCE='$exp',IMAGE='$file_destination'  where S_NO='$id'");
                  $_SESSION['error']="Updated Succeessfully !!";
                  header("location:staff.php");
                  }
                  else{
                        $_SESSION['error']="Upload Image of size < 10MB";
                        header("location:staff.php");
                  }
            }
            else{
                  $_SESSION['error']="Error in uploading Image";
                  header("location:staff.php");
            }
      }
      else{
            $_SESSION['error']="File extension must be 'png' or 'jpg' or 'jpeg'";
            header("location:staff.php");
      }
 }
}
 else if($for=="student"){
      if($file_error=="4"){
            $name= strtoupper($_POST['std_name']);
            $id=$_POST['std_id'];
            $class=$_POST['std_class'];
            $fee=$_POST['std_fee'];
            mysqli_query($conn,"UPDATE student set NAME='$name',id='$id',class='$class',fee='$fee' where id='$id'");
            header("location:student.php?m=r");
      }
      else{
      
      $file_ext=explode('.' , $file_name);
      $file_act_ext=strtolower(end($file_ext));

      $allowed_ext=array('png','jpg','jpeg');

      if(in_array( $file_act_ext , $allowed_ext)){
            if($file_error=== 0){
                  if($file_size < 10000000){
                  $file_new_name=uniqid('',true).".". $file_act_ext;
                  $file_destination = "../images/staff/". $file_new_name;
                  //$file_destination= "../try/".$file_new_name;
      
                  move_uploaded_file($file_Temp, $file_destination);
                  $row=mysqli_fetch_assoc(mysqli_query($conn,"select * from student where id='$id'"));
                  unlink($row['photo']);
                  $name= strtoupper($_POST['std_name']);
                  $id=$_POST['std_id'];
                  $class=$_POST['std_class'];
                  $fee=$_POST['std_fee'];
                  mysqli_query($conn,"UPDATE student set NAME='$name',id='$id',class='$class',fee='$fee', photo='$file_destination' where id='$id'");
                  
                  $_SESSION['error']="Updated Succeessfully !!";
                  header("location:student.php?m=r");
                  }
                  else{
                        $_SESSION['error']="Upload Image of size < 10MB";
                        header("location:student.php?m=r");
                  }
            }
            else{
                  $_SESSION['error']="Error in uploading Image";
                  header("location:student.php?m=r");
            }
      }
      else{
            $_SESSION['error']="File extension must be 'png' or 'jpg' or 'jpeg' instudentz";
            header("location:student.php?m=r");
      }
     }
}
else if($for=="pdf"){
      if($file_error=="4"){
            header("location:pdf.php");
      }
      else{
      
      $file_ext=explode('.' , $file_name);
      $file_act_ext=strtolower(end($file_ext));

      $allowed_ext=array('pdf','docs','.txt');

      if(in_array( $file_act_ext , $allowed_ext)){
            if($file_error=== 0){
                  if($file_size < 10000000){
                  $file_new_name=uniqid('',true).".". $file_act_ext;
                  if($id=="C"){
                        $file_destination = "../document/Calender/". $file_new_name;
                        $sql="update pdf set file='$file_destination' where name='Calender'";
                        $row=mysqli_fetch_assoc(mysqli_query($conn,"select * from pdf where name='Calender'"));
                        unlink($row['file']);
                  }
                  else if($id=="F"){
                        $file_destination = "../document/Fees Structure/". $file_new_name;
                        $sql="update pdf set file='$file_destination' where name='Fee Structure'";
                        $row=mysqli_fetch_assoc(mysqli_query($conn,"select * from pdf where name='Fee Structure'"));
                        unlink($row['file']);
                  }
                  
                  //$file_destination= "../try/".$file_new_name;
      
                  move_uploaded_file($file_Temp, $file_destination);
                  
                  mysqli_query($conn,$sql);
                  $_SESSION['error']="Updated Succeessfully !!";
                  header("location:pdf.php");
                  }
                  else{
                        $_SESSION['error']="Upload Image of size < 10MB";
                        header("location:pdf.php");
                  }
            }
            else{
                  $_SESSION['error']="Error in uploading Image";
                  header("location:pdf.php");
            }
      }
      else{
            $_SESSION['error']="File extension must be 'png' or 'jpg' or 'jpeg' instudentz";
            header("location:student.php?m=r");
      }
     }
}

else if($for=="ach"){
      if($file_error=="4"){
            $name= strtoupper($_POST['data_name']);
            $text=$_POST['data_des'];
            $type=substr($_POST['data_ach'],0,1);
            $year=$_POST['data_year'];
            mysqli_query($conn,"UPDATE achieve set NAME='$name',TYPE='$type',YEAR=$year,TEXT='$text' where S_NO='$id'");
            header("location:ach.php");
      }
      else{
      
      $file_ext=explode('.' , $file_name);
      $file_act_ext=strtolower(end($file_ext));

      $allowed_ext=array('png','jpg','jpeg');

      if(in_array( $file_act_ext , $allowed_ext)){
            if($file_error=== 0){
                  if($file_size < 10000000){
                  $file_new_name=uniqid('',true).".". $file_act_ext;
                  $file_destination = "../images/top_students/". $file_new_name;
                  //$file_destination= "../try/".$file_new_name;
      
                  move_uploaded_file($file_Temp, $file_destination);
                  $row=mysqli_fetch_assoc(mysqli_query($conn,"select * from achieve where S_NO='$id'"));
                  unlink($row['IMAGE']);
                  $name= strtoupper($_POST['data_name']);
                  $text=$_POST['data_des'];
                  $type=substr($_POST['data_ach'],0,1);
                  $year=$_POST['data_year'];
                  mysqli_query($conn,"UPDATE achieve set NAME='$name',TYPE='$type',YEAR=$year,TEXT='$text',IMAGE='$file_destination' where S_NO='$id'");
                  
                  $_SESSION['error']="Updated Succeessfully !!";
                  header("location:ach.php");
                  }
                  else{
                        $_SESSION['error']="Upload Image of size < 10MB";
                        header("location:ach.php");
                  }
            }
            else{
                  $_SESSION['error']="Error in uploading Image";
                  header("location:ach.php");
            }
      }
      else{
            $_SESSION['error']="File extension must be 'png' or 'jpg' or 'jpeg' instudentz";
            header("location:ach.php");
      }
     }
}
 

?>