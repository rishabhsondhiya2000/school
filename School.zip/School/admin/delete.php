<?php
require('conn.php');
$id=$_POST['id'];
$for=$_GET['f'];

if($for=='photo'){
    $res=mysqli_query($conn,"select * from photos where S_NO='$id'");
    $row=mysqli_fetch_assoc($res);
    unlink($row['IMAGE']);
    mysqli_query($conn,"DELETE from photos where S_NO='$id'");
    echo"Deleted SuccessFully !! ";
}

?>