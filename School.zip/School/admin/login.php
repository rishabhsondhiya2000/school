<?php
   require('conn.php');
   require('mail\index.php');
   session_start();
   $error="";
    if(isset($_SESSION['error'])){
        $error=$_SESSION['error'];
        $_SESSION['error']="";
    }
   if(isset($_SESSION['isLogin'])){
    header("location:dashboard.php");
   }

//    if(isset($_REQUEST['updatepass'])){
//        $pass=$_POST['password'];
//        $conf_pass=$_POST['confirm_password'];
//        if($pass==$conf_pass){
//            mysqli_query($conn,"UPDATE admin set password='$pass'");
//            $_SESSION["error"]="Password is updated! Log In now :)";
//            $_SESSION['mode']="login";
//            header("location:login.php");
//        }
//        else{
//            $_SESSION['error']="Confrim Password not matched";
//            header('location:login.php');
//        }
//    }

   function send_otp($email){
        $emailOTP=rand(1000,9999);
        // echo $emailOTP;
        setcookie("email",$email,time()+30);
        setcookie("emailOTP",$emailOTP,time()+30);
        if(smtp_mailer($email,'OTP for change password',"Your OTP is : $emailOTP")==0){
            $_SESSION['error']="Unable to send Email Right Now!!!";
            header("location:login.php?m=forget");
        }
        else {
            $_SESSION['mode']="sent";
            header("location:login.php");
        }
   }

    if(isset($_REQUEST['submit'])){
           $email=$_POST['emailid'];
           $pass=$_POST['pass'];
           $res=mysqli_query($conn,"select * from admin where email='$email' and password='$pass'");
           $count=mysqli_num_rows($res);
           
           if($count ==1){
               $_SESSION['isLogin']=1;
               header("location:dashboard.php");
           }
           else{
               $_SESSION['error']="Wrong Id or Password :(";
           }
    }
    if(isset($_REQUEST['otpsent'])){
        $email=$_POST['emailid'];
        $res=mysqli_query($conn,"select * from admin where email='$email' ");
        $count=mysqli_num_rows($res);
        
        if($count == 1){
            send_otp($email);
        }
        else{
            $_SESSION['error']="Enter Registerd Email ID";
        }
    }
    
    $mode="login";
    if(isset($_GET['m'])){
        $mode=$_GET['m'];
    }
    else if(isset($_SESSION['mode'])){
        $mode=$_SESSION['mode'];
        if($mode!="change")
        $_SESSION['mode']="login";
    }
    


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOG IN </title>
    <link rel="shortcut icon" href="../favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="css/login3.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
</head>
<body>
    <div class="box">
     <?php
        if($mode=="login"){ ?>
            <form action="" method="POST">
                <h3 class="heading">LOG IN TO PANEL:</h3>   
                <div class="form-group">
                    <label for="exampleInputEmail1"><b>Email address:</b></label>
                    <input type="email" name="emailid" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                    
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1"> <b>Password:</b> </label>
                    <input type="password" name="pass" class="form-control" id="exampleInputPassword1" placeholder="Password">
                    <a class="forget" href="login.php?m=forget"><b>forget Password?</b></a>
                </div>
            
                <div class="error">
                    <b><?php echo $error;?></b>
                </div>
                <button type="submit" name="submit" class="color" >Submit</button>
            </form>
      <?php  }
        else if($mode=="forget"){ ?>
              <form action="" method="POST">
                <h3 class="heading">Enter Account Email Id:</h3>   
                <div class="form-group">
                    <label for="exampleInputEmail1"><b>Email address:</b></label>
                    <input type="email" name="emailid" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                    
                </div>
            
                <div class="error">
                    <b><?php echo $error;?></b>
                </div>
                <button type="submit" name="otpsent" class="color" >Send OTP</button>
            </form>
      <?php }
        else if($mode=="sent"){ ?>
               <p class="error"><b>** Don't refreh the page. **<b></p>
              <form action="check.php" method="POST">
                <h3 class="heading">Enter OTP:</h3>   
                <div class="form-group">
                    <label for="exampleInputEmail1"><b>OTP:</b></label>
                    <input type="text" name="otp" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter OTP">
                </div>
            
                <div class="error">
                    <b><?php echo $error;?></b>
                </div>
                <button type="submit" name="checkotp" class="color" >Check OTP</button>
                 <div id="timer">
                 </div>
            </form>
        <?php   }
         else if($mode=="change"){ ?>
              <form action="updatepass.php" method="POST">   
                  <h2>Change Password :</h2>
                <div class="form-group">
                    <label for="exampleInputEmail1"><b>Enter Password:</b></label>
                    <input type="text" name="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter new Password">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1"><b>Confirm Password:</b></label>
                    <input type="text" name="confirm_password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Confirm Password">
                </div>
            
                <div class="error">
                    <b><?php echo $error;?></b>
                </div>
                <button type="submit" name="updatepass" class="color" >Update</button>
             </form>
           <?php } ?>   
    
    
    </div>

    <script>
        var i=30;
        var my =setInterval(() => {
            document.getElementById('timer').innerHTML="Timer : "+i;
            i--;
            if(i<0){
                document.getElementById('timer').innerHTML='Session Expired';
                clearInterval(my);
                setTimeout(() => {
                    window.location.replace("login.php");
                }, 1000);     
            }
        }, 1000);
    </script>
</body>
</html>