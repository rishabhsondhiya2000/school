<?php
 require('conn.php');
 $for=$_GET['f'];
 $file_name=$_FILES['file']['name'];
 $file_Temp=$_FILES['file']['tmp_name'];
 $file_size=$_FILES['file']['size'];
 $file_type=$_FILES['file']['type'];
 $file_error=$_FILES['file']['error'];

 $file_ext=explode('.' , $file_name);
 $file_act_ext=strtolower(end($file_ext));

 $allowed_ext=array('png','jpg','jpeg');
if($for=="staff"){

 if(in_array( $file_act_ext , $allowed_ext)){
       if($file_error=== 0){
            if($file_size < 10000000){
                $file_new_name=uniqid('',true).".". $file_act_ext;
                $file_destination = "../images/staff/". $file_new_name;
 
                 move_uploaded_file($file_Temp, $file_destination);
                 $name= strtoupper($_POST['data_name']);
                 $age=$_POST['data_age'];
                 $exp=$_POST['data_exp'];
                 $post=$_POST['data_post'];
                 mysqli_query($conn,"INSERT into teachers(NAME,AGE,POST,EXPERIENCE,IMAGE) values('$name','$age','$post','$exp','$file_destination') ");
                 
                 $_SESSION['error']="Inserted Succeessfully !!";
                 header('location:staff.php');
             }
       }
 }

}
else if($for=="student"){
    if(in_array( $file_act_ext , $allowed_ext)){
        if($file_error=== 0){
             if($file_size < 10000000){
                 $file_new_name=uniqid('',true).".". $file_act_ext;
                 $file_destination = "../images/students/". $file_new_name;
  
                  move_uploaded_file($file_Temp, $file_destination);
                  $name= strtoupper($_POST['std_name']);
                  $id=$_POST['std_id'];
                  $class=$_POST['std_class'];
                  $fee=$_POST['std_fee'];
                  mysqli_query($conn,"INSERT into student(id,name,class,fee,photo) values('$id','$name','$class','$fee','$file_destination') ");
                  $_SESSION['error']="Inserted Succeessfully !!";
                  header('location:student.php?m=r');
              }
        }
  }
}

else if($for=="photo"){
    if(in_array( $file_act_ext , $allowed_ext)){
        if($file_error=== 0){
             if($file_size < 10000000){
                 $place= strtolower($_POST['place']);
                 $file_new_name=uniqid('',true).".". $file_act_ext;
                 $file_destination = "../images/".$place."/". $file_new_name;
  
                  move_uploaded_file($file_Temp, $file_destination);
                  $place= $_POST['place'];
                  mysqli_query($conn,"INSERT into photos(PLACE,IMAGE) values('$place','$file_destination') ");
                  $_SESSION['error']="Inserted Succeessfully !!";
                  header('location:pic.php');
              }
        }
   }
}

else if($for=="ach"){
    if(in_array( $file_act_ext , $allowed_ext)){
        if($file_error=== 0){
             if($file_size < 10000000){
                 
                 $file_new_name=uniqid('',true).".". $file_act_ext;
                 $file_destination = "../images/top_students/". $file_new_name;
  
                  move_uploaded_file($file_Temp, $file_destination);
                  
                  $name= strtoupper($_POST['data_name']);
                  $text=$_POST['data_des'];
                  $type=substr($_POST['data_ach'],0,1);
                  $year=$_POST['data_year'];
                  mysqli_query($conn,"UPDATE achieve set NAME='$name',TYPE='$type',YEAR=$year,TEXT='$text',IMAGE='$file_destination' where S_NO='$id'");
                  
                  mysqli_query($conn,"INSERT into achieve(NAME,TYPE,YEAR,TEXT,IMAGE) values('$name','$type','$year','$text','$file_destination') ");
                  $_SESSION['error']="Inserted Succeessfully !!";
                  header("location:ach.php");
              }
        }
   }
}

else if($for=="slider"){
    if(in_array( $file_act_ext , $allowed_ext)){
        if($file_error=== 0){
             if($file_size < 10000000){
                 $place= strtolower($_POST['place']);
                 $file_new_name=uniqid('',true).".". $file_act_ext;
                 $file_destination = "../images/slider/". $file_new_name;
  
                  move_uploaded_file($file_Temp, $file_destination);
                  $id= $_POST['id'];
                  mysqli_query($conn,"INSERT into slider(id,image) values('$id','$file_destination') ");
                  $_SESSION['error']="Inserted Succeessfully !!";
                  header('location:slider.php');
              }
              else{
                  $_SESSION['error']="File size must be < 10MB";
                  header('location:slider.php');
              }
        }
        else{
            $_SESSION['error']="There is some error in Uploading Image";
            header('location:slider.php');
        }
   }
   else{
    $_SESSION['error']="File extension must be png,jpeg,jpg";
    header('location:slider.php');
   }
}
 

?>