<?php
 $conn=mysqli_connect("localhost","root","","school");
 if(!$conn){
     die("Server connection Lost");
 }

?>