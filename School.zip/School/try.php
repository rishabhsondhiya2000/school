<?php
   unlink("document/Admission/sign.pdf");

?>