<?php
  require('conn.php');
  $class=$_POST['cl'];
        if($class!=0){
        $sql="SELECT * FROM course where class=$class ";
        $res=mysqli_query($conn,$sql);
        echo'
        <div  class="select-subject">
        <table >
               <tr>
                      <th>Code</th>
                      <th>Subject</th>
                      <th>View</th>
                      <th>Book</th>
               </tr>
        ';
        while($row=mysqli_fetch_assoc($res)){ 
               $book=substr($row['book'],3);
                echo"
                <tr>
                   <td>".$row['code']."</td>
                   <td>".$row['name']."</td>
                   <td><a target='_blank' href='".$row['file']."'>View Course</a></td>
                   <td><a target='_blank' href='".$book."'>View Book</a></td>
                </tr>
                ";
            }
         echo"</table>";   
      }
      else{
        echo "select class";
      }

                        

?>