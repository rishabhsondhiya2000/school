<?php
  if(isset($_POST['submit'])){
      $name=$_FILES['file'];
    
      $file_name=$_FILES['file']['name'];
      $file_Temp=$_FILES['file']['tmp_name'];
      $file_size=$_FILES['file']['size'];
      $file_type=$_FILES['file']['type'];
      $file_error=$_FILES['file']['error'];

      $file_ext=explode('.' , $file_name);
      $file_act_ext=strtolower(end($file_ext));

      $allowed_ext=array('png','jpg','jpeg');

      if(in_array( $file_act_ext , $allowed_ext)){
            if($file_error=== 0){
                 if($file_size < 10000000){
                     $file_new_name=uniqid('',true).".". $file_act_ext;
                     $file_destination = "uploads/". $file_new_name;

                     move_uploaded_file($file_Temp, $file_destination);
                     
                 }
                 else{
                     echo"Your file size is too big";
                 }
            }
            else{
                echo"Error in uploading your file";
            }
      }
      else{
          echo"You cannot upload this type of file.";
      }
  }
?>